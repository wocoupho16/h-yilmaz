#ifndef PROCESSOR_H
#define PROCESSOR_H

class Processor 
{
 public:
  float Utilization();  

 private:
 float totalAmount;
 float idleAmount;
 float prevTotal;
 float prevIdle;
};

#endif