#include <unistd.h>
#include <cctype>
#include <sstream>
#include <string>
#include <vector>

#include "process.h"
#include "linux_parser.h"

using std::string;
using std::to_string;
using std::vector;

Process::Process(int pid) { this->pid_ = pid; }

int Process::Pid() { return this->pid_; }

float Process::CpuUtilization()
{
  float activeJiffie = static_cast<float>(LinuxParser::ActiveJiffies());
  float upTime = static_cast<float>(LinuxParser::UpTime());
  float upTimePid = static_cast<float>(LinuxParser::UpTime(this->pid_));
  float seconds = (upTime - upTimePid) / static_cast<float>(sysconf(_SC_CLK_TCK));
  
  cpu_utilization_ = (activeJiffie / static_cast<float>(sysconf(_SC_CLK_TCK)) / seconds);
    
  return cpu_utilization_ / 100; 
}

string Process::Command() { return string(LinuxParser::Command(this->pid_)); }

string Process::Ram() { return string(LinuxParser::Ram(this->pid_)); }

string Process::User() { return string(LinuxParser::User(this->pid_)); }

long int Process::UpTime() { return LinuxParser::UpTime(this->pid_);; }

bool Process::operator<(Process const& a) const 
{
  return this->cpu_utilization_ < a.cpu_utilization_;
}