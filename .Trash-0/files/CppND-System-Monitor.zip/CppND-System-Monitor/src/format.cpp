#include <string>

#include "format.h"

using std::string;
using std::to_string;

string Format::ElapsedTime(long seconds) 
{ 
    // Declare variables
	int hour = 0;
	int minute = 0;
	int second = 0;
    string formattedTime = "";

    hour = seconds / 3600;
	seconds = seconds % 3600;
	minute = seconds / 60;
	seconds = seconds % 60;
	second = seconds;

    if (hour < 10)
        formattedTime += "0";
    formattedTime += to_string(hour) + ":";

    if (minute < 10)
        formattedTime += "0";
    formattedTime += to_string(minute) + ":";

    if (second < 10)
        formattedTime += "0";
    formattedTime += to_string(second);

    return formattedTime; 
}