#include "processor.h"
#include "linux_parser.h"

float Processor::Utilization() 
{
  totalAmount = LinuxParser::Jiffies() - prevTotal;
  idleAmount = LinuxParser::IdleJiffies() - prevIdle;

  prevTotal = LinuxParser::Jiffies();
  prevIdle = LinuxParser::IdleJiffies();

  return (totalAmount - idleAmount) / totalAmount;
}