#include <dirent.h>
#include <unistd.h>
#include <string>
#include <vector>

#include "linux_parser.h"

using std::stof;
using std::string;
using std::to_string;
using std::vector;

string LinuxParser::OperatingSystem() 
{
  string line;
  string key;
  string value;
  std::ifstream filestream(kOSPath);
  
  if (filestream.is_open()) 
  {
    while (std::getline(filestream, line)) 
    {
      std::replace(line.begin(), line.end(), ' ', '_');
      std::replace(line.begin(), line.end(), '=', ' ');
      std::replace(line.begin(), line.end(), '"', ' ');
      
      std::istringstream linestream(line);
      
      while (linestream >> key >> value) 
      {
        if (key == "PRETTY_NAME") 
        {
          std::replace(value.begin(), value.end(), '_', ' ');
          return value;
        }
      }
    }
  }
  
  return value;
}

string LinuxParser::Kernel() 
{
  string os, kernel, version;
  string line;
  std::ifstream stream(kProcDirectory + kVersionFilename);
  
  if (stream.is_open()) 
  {
    std::getline(stream, line);
    std::istringstream linestream(line);
    linestream >> os >> kernel >> version;
  }
  
  return version;
}

// BONUS: Update this to use std::filesystem
vector<int> LinuxParser::Pids() 
{
  vector<int> pids;
  DIR* directory = opendir(kProcDirectory.c_str());
  struct dirent* file;
  
  while ((file = readdir(directory)) != nullptr) 
  {
    // Is this a directory?
    if (file->d_type == DT_DIR) 
    {
      // Is every character of the name a digit?
      string filename(file->d_name);
      
      if (std::all_of(filename.begin(), filename.end(), isdigit)) 
      {
        int pid = stoi(filename);
        pids.push_back(pid);
      }
    }
  }
  closedir(directory);
  
  return pids;
}

float LinuxParser::MemoryUtilization() 
{
  string line;
  string key;
  string value;
  int row{0};
  float memTotal{0.0f};
  float memFree{0.0f};
  std::ifstream stream(kProcDirectory + kMeminfoFilename);
  
  while (stream.is_open() && row < 2)
  {
    std::getline(stream, line);
    std::istringstream linestream(line);
    linestream >> key >> value;
    if (key == "MemTotal:")
      memTotal = stof(value);
    else if (key == "MemFree:")
      memFree = stof(value);
    else
      /* This cannot enter here */
    
    row++;
  }
  
  return ( (100.0 * (memTotal - memFree) ) / memTotal) / 100.0; 
}

long LinuxParser::UpTime()
{
  string line;
  string upTime;
  string idleTime;
  std::ifstream stream(kProcDirectory + kUptimeFilename);
  
  if (stream.is_open()) 
  {
    std::getline(stream, line);
    std::istringstream linestream(line);
    linestream >> upTime >> idleTime;
  }

  return stoi(upTime);
}

long LinuxParser::Jiffies()
{
  vector<string> cpuUtilization = LinuxParser::CpuUtilization();
  long jiffies{0};
  
  for (int i = kUser_; i <= kSteal_; i++)
    jiffies += std::stol(cpuUtilization[i]);
  
  return jiffies;
}

long LinuxParser::ActiveJiffies(int pid)
{
  vector<string> buffer;
  std::string line;
  long totalTime{0};
  std::ifstream filestream(kProcDirectory + to_string(pid) + kStatFilename);
  
  if (filestream.is_open()) 
  {
    std::getline(filestream, line);
    std::stringstream sstream(line);
    
    while (std::getline(sstream, line, ' ')) 
    {
      buffer.push_back(line);
    }
    
    totalTime = std::stol(buffer[13]) + std::stol(buffer[14]) + std::stol(buffer[15]) + std::stol(buffer[16]);
  }
  
  return totalTime;
}

long LinuxParser::ActiveJiffies()
{
  return LinuxParser::Jiffies() - LinuxParser::IdleJiffies();
}

long LinuxParser::IdleJiffies()
{
  vector<string> cpuUtilization = LinuxParser::CpuUtilization();
  long idleJiffies{0};
  
  for (int i = kIdle_; i <= kIOwait_; i++)
    idleJiffies += std::stol(cpuUtilization[i]);
  
  return idleJiffies;
}

vector<string> LinuxParser::CpuUtilization()
{
  string line,val;
  vector <string> cpuUsage;
  std::ifstream file(kProcDirectory + kStatFilename);
  
  if (file.is_open())
  {
    std::getline(file,line);
    std::istringstream stream(line);
    while (stream >> val)
    {
      if(val!="cpu")
        cpuUsage.emplace_back(val);
    };
  }
  
  return cpuUsage;
}

int LinuxParser::TotalProcesses()
{ 
  string key, value;
  string line;
  string totalProcess;
  string searchString("processes");
  std::ifstream stream(kProcDirectory + kStatFilename);
  
  if (stream.is_open())
  {
    while (std::getline(stream, line))
    {
    	std::size_t found = line.find(searchString);
    	if (found != std::string::npos)
    		totalProcess = line.substr(searchString.size());
    }
  }
  
  return stoi(totalProcess); 
}

int LinuxParser::RunningProcesses()
{
  string key, value;
  string line;
  string runningProcess;
  std::ifstream stream(kProcDirectory + kStatFilename);
  
  if (stream.is_open())
  {
    while (std::getline(stream, line))
    {
  		std::istringstream linestream(line);
    	linestream >> key >> value;
    	if(key == "procs_running")
      		runningProcess = value;
    }
  }
  
  return stoi(runningProcess); 
}

string LinuxParser::Command(int pid)
{ 
  string line;
  string key, value;
  string user;
  std::ifstream stream(kProcDirectory + to_string(pid) + kCmdlineFilename);
  
  if (stream.is_open())
  {
  	std::getline(stream, line);
  }
  
  return string(line);
}

string LinuxParser::Ram(int pid)
{
  string line;
  string key, value;
  int vmSize;
  std::ifstream stream(kProcDirectory + to_string(pid) + kStatusFilename);
  
  if (stream.is_open())
  {
  	while (std::getline(stream, line))
    {
      std::istringstream linestream(line);
      linestream >> key >> value;
      if (key == "VmSize:")
          vmSize = std::stoi(value) / 1024;
    }
  }
  
  return string(to_string(vmSize)); 
}

string LinuxParser::Uid(int pid)
{
  string line;
  string key, value;
  string uid;
  std::ifstream stream(kProcDirectory + to_string(pid) + kStatusFilename);
  
  if (stream.is_open())
  {
  	while (std::getline(stream, line))
    {
      std::istringstream linestream(line);
      linestream >> key >> value;
      if (key == "Uid:")
      		uid = value;
    }
  }
  
  return string(uid); 
}

string LinuxParser::User(int pid)
{ 
  string line;
  string user, x, uid;
  string username;
  std::ifstream stream(kPasswordPath);
  
  if (stream.is_open())
  {
  	while (std::getline(stream, line))
    {
      std::replace(line.begin(), line.end(), ':', ' ');
      std::istringstream linestream(line);
      linestream >> user >> x >> uid;
      if (uid == LinuxParser::Uid(pid))
      		username = user;
    }
  }
  
  return string(username);
}

long LinuxParser::UpTime(int pid) 
{
  string line;
  string skippedValue;
  long searchedValue{0};
  std::ifstream stream(kProcDirectory + to_string(pid) + kStatFilename);
  
  if (stream.is_open()) 
  {
    std::getline(stream, line);
    std::istringstream linestream(line);
    
    for(int i = 0; i < 21; i++) 
      linestream >> skippedValue;
    
    linestream >> searchedValue;
  }
  
  return (searchedValue / sysconf(_SC_CLK_TCK));
}